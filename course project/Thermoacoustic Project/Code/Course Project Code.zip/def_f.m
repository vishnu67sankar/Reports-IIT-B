function f = def_f(t, eta, eta_t)    
    %f = eta;
    f = eta_t;
end